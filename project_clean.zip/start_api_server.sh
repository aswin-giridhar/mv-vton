#!/bin/bash

# MV-VTON API Server Startup Script
# This script activates the conda environment and starts the API server

set -e  # Exit on any error

echo "🚀 MV-VTON API Server Startup Script"
echo "====================================="

# Check if conda is available
if ! command -v conda &> /dev/null; then
    echo "❌ Conda not found. Please install conda or miniconda."
    exit 1
fi

# Initialize conda for shell script
eval "$(conda shell.bash hook)"

# Check if mv-vton environment exists
if ! conda env list | grep -q "mv-vton"; then
    echo "❌ mv-vton conda environment not found."
    echo "Please create it with: conda env create -f environment.yaml"
    exit 1
fi

echo "🔧 Activating mv-vton conda environment..."
conda activate mv-vton

echo "🧪 Running setup tests..."
python test_api_setup.py

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ All tests passed! Starting API server..."
    echo "🌐 Server will be available at: http://localhost:5000"
    echo "📖 Health check: http://localhost:5000/health"
    echo ""
    echo "Press Ctrl+C to stop the server"
    echo "====================================="
    echo ""
    
    # Start the API server
    python mvvton_api_server.py
else
    echo "❌ Setup tests failed. Please check the environment setup."
    exit 1
fi