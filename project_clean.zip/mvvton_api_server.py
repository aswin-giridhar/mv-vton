"""
Integrated MV-VTON API Server
A complete implementation that properly integrates with the original MV-VTON codebase
"""

import os
import sys
import argparse
import torch
import numpy as np
import io
import base64
import tempfile
import traceback
import cv2
import json
from datetime import datetime
from pathlib import Path

from flask import Flask, request, jsonify, send_file
# Fix for pydantic compatibility issues
import warnings
warnings.filterwarnings("ignore", message=".*Pydantic.*")
from PIL import Image, ImageDraw
from omegaconf import OmegaConf
from torchvision import transforms
from torchvision.transforms import Resize
from pytorch_lightning import seed_everything
from torch import autocast
from contextlib import nullcontext
import torchvision

# Add the current directory to Python path
sys.path.append(os.getcwd())

# Import MV-VTON modules
from ldm.util import instantiate_from_config
from ldm.models.diffusion.ddim import DDIMSampler
from ldm.models.diffusion.plms import PLMSSampler

app = Flask(__name__)

# Configure Flask to avoid pydantic conflicts
app.config['JSON_SORT_KEYS'] = False
app.config['JSONIFY_PRETTYPRINT_REGULAR'] = True

# Global variables for model state
model = None
sampler = None
device = None
config = None
vgg_model = None

# Configuration constants
DEFAULT_CONFIG_PATH = "configs/viton512.yaml"
DEFAULT_CHECKPOINT_PATH = "checkpoint/mvg.ckpt"
DEFAULT_VGG_PATH = "models/vgg/vgg19_conv.pth"
DEFAULT_IMAGE_SIZE = (512, 384)  # H, W
DEFAULT_DDIM_STEPS = 30
DEFAULT_SCALE = 1.0

def load_model_from_config(config, ckpt, verbose=False):
    """Load model from checkpoint (adapted from test.py)"""
    print(f"Loading model from {ckpt}")
    pl_sd = torch.load(ckpt, map_location="cpu")
    if "global_step" in pl_sd:
        print(f"Global Step: {pl_sd['global_step']}")
    sd = pl_sd["state_dict"]
    model = instantiate_from_config(config.model)
    m, u = model.load_state_dict(sd, strict=False)
    if len(m) > 0 and verbose:
        print("missing keys:")
        print(m)
    if len(u) > 0 and verbose:
        print("unexpected keys:")
        print(u)

    model.cuda()
    model.eval()
    return model

def initialize_mvvton_model(config_path=None, checkpoint_path=None, use_plms=False):
    """Initialize the complete MV-VTON model pipeline"""
    global model, sampler, device, config
    
    try:
        # Set device
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Using device: {device}")
        
        # Set paths with defaults
        config_path = config_path or DEFAULT_CONFIG_PATH
        checkpoint_path = checkpoint_path or DEFAULT_CHECKPOINT_PATH
        
        # Verify files exist
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Config file not found: {config_path}")
        if not os.path.exists(checkpoint_path):
            raise FileNotFoundError(f"Checkpoint file not found: {checkpoint_path}")
            
        # Load configuration
        config = OmegaConf.load(config_path)
        print(f"Loaded config from {config_path}")
        
        # Load model
        model = load_model_from_config(config, checkpoint_path, verbose=True)
        print("✅ MV-VTON model loaded successfully!")
        
        # Create sampler
        if use_plms:
            sampler = PLMSSampler(model)
            print("✅ PLMS sampler created!")
        else:
            sampler = DDIMSampler(model)
            print("✅ DDIM sampler created!")
        
        # Set random seed for reproducibility
        seed_everything(42)
        
        return True
        
    except Exception as e:
        print(f"❌ Error initializing MV-VTON model: {e}")
        traceback.print_exc()
        return False

def get_transforms():
    """Get the image transformations used by MV-VTON"""
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])
    
    clip_normalize = transforms.Normalize(
        (0.48145466, 0.4578275, 0.40821073),
        (0.26862954, 0.26130258, 0.27577711)
    )
    
    transform_mask = transforms.Compose([
        transforms.ToTensor()
    ])
    
    return transform, clip_normalize, transform_mask

def preprocess_person_image(person_img, target_size=DEFAULT_IMAGE_SIZE):
    """Preprocess person image for MV-VTON"""
    transform, _, _ = get_transforms()
    
    # Resize and transform
    H, W = target_size
    person_img = person_img.resize((W, H), Image.LANCZOS)
    person_tensor = transform(person_img)
    
    return person_tensor

def preprocess_cloth_image(cloth_img, target_size=DEFAULT_IMAGE_SIZE):
    """Preprocess cloth image for MV-VTON with improved cloth masking"""
    transform, clip_normalize, _ = get_transforms()
    
    H, W = target_size
    cloth_img = cloth_img.resize((W, H), Image.LANCZOS)
    cloth_tensor = transform(cloth_img)
    
    # Create cloth mask using simple background removal
    # Convert to numpy for processing
    cloth_np = np.array(cloth_img)
    
    # Create mask by detecting non-white areas (assuming white/light background)
    # This is a simple approach - in production use proper cloth segmentation
    gray = cv2.cvtColor(cloth_np, cv2.COLOR_RGB2GRAY)
    _, binary_mask = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY_INV)
    
    # Clean up the mask
    kernel = np.ones((3,3), np.uint8)
    binary_mask = cv2.morphologyEx(binary_mask, cv2.MORPH_CLOSE, kernel)
    binary_mask = cv2.morphologyEx(binary_mask, cv2.MORPH_OPEN, kernel)
    
    # Convert back to tensor
    cloth_mask = torch.from_numpy(binary_mask).float() / 255.0
    cloth_mask = cloth_mask.unsqueeze(0)  # Add channel dimension
    
    # Extract reference image (simulate bbox extraction)
    ref_image = cloth_tensor.clone()
    ref_image = (ref_image + 1.0) / 2.0  # Denormalize
    ref_image = transforms.Resize((224, 224))(ref_image)
    ref_image = clip_normalize(ref_image)
    
    return cloth_tensor, ref_image, cloth_mask

def create_simple_skeleton_pose(target_size=DEFAULT_IMAGE_SIZE):
    """DEPRECATED: Create a simple skeleton pose (placeholder - should use pose detection)"""
    H, W = target_size
    transform, _, _ = get_transforms()
    
    # Create a blank image for skeleton
    skeleton_img = Image.new('RGB', (W, H), color=(0, 0, 0))
    draw = ImageDraw.Draw(skeleton_img)
    
    # Draw a very simple stick figure (placeholder)
    # Head
    draw.ellipse([W//2-10, 50, W//2+10, 70], fill='white')
    # Body
    draw.line([W//2, 70, W//2, H-100], fill='white', width=3)
    # Arms
    draw.line([W//2, 120, W//2-40, 180], fill='white', width=3)
    draw.line([W//2, 120, W//2+40, 180], fill='white', width=3)
    # Legs
    draw.line([W//2, H-100, W//2-30, H-20], fill='white', width=3)
    draw.line([W//2, H-100, W//2+30, H-20], fill='white', width=3)
    
    skeleton_tensor = transform(skeleton_img)
    return skeleton_tensor

def create_proper_skeleton_pose(person_image, target_size=DEFAULT_IMAGE_SIZE):
    """Create proper 18-point OpenPose style skeleton using integrated preprocessing"""
    H, W = target_size
    transform, _, _ = get_transforms()
    
    try:
        # Import the integrated preprocessing module
        sys.path.append('/home/ubuntu/MV-VTON')
        from integrated_preprocessing import IntegratedMVVTONPreprocessor
        
        print("🦴 Using integrated OpenPose and SCHP preprocessing...")
        
        # Create preprocessor and extract pose
        preprocessor = IntegratedMVVTONPreprocessor(target_size=target_size, device=device)
        person_data = preprocessor.process_person_image(person_image)
        
        # Return the pose tensor (already in correct format)
        return person_data['pose']
        
    except Exception as e:
        print(f"⚠️ Integrated preprocessing failed ({e}), using improved fallback pose")
        print(f"   Error details: {traceback.format_exc()}")
        return create_improved_fallback_skeleton_pose(target_size)

def create_improved_fallback_skeleton_pose(target_size=DEFAULT_IMAGE_SIZE):
    """Improved fallback skeleton pose with 18-point structure"""
    H, W = target_size
    transform, _, _ = get_transforms()
    
    skeleton_img = Image.new('RGB', (W, H), color=(0, 0, 0))
    draw = ImageDraw.Draw(skeleton_img)
    
    # 18-point OpenPose structure
    poses = {
        0: (W//2, H//8),        # nose
        1: (W//2, H//4),        # neck
        2: (2*W//3, H//4),      # right shoulder
        3: (3*W//4, 2*H//5),    # right elbow
        4: (5*W//6, 3*H//5),    # right wrist
        5: (W//3, H//4),        # left shoulder
        6: (W//4, 2*H//5),      # left elbow
        7: (W//6, 3*H//5),      # left wrist
        8: (3*W//5, 3*H//5),    # right hip
        9: (3*W//5, 4*H//5),    # right knee
        10: (3*W//5, 9*H//10),  # right ankle
        11: (2*W//5, 3*H//5),   # left hip
        12: (2*W//5, 4*H//5),   # left knee
        13: (2*W//5, 9*H//10),  # left ankle
        14: (11*W//20, H//12),  # right eye
        15: (9*W//20, H//12),   # left eye
        16: (12*W//20, H//12),  # right ear
        17: (8*W//20, H//12),   # left ear
    }
    
    # OpenPose connections
    connections = [
        (0, 1), (1, 2), (1, 5),     # head to shoulders
        (2, 3), (3, 4),             # right arm
        (5, 6), (6, 7),             # left arm  
        (1, 8), (1, 11),            # torso
        (8, 11),                    # hips
        (8, 9), (9, 10),            # right leg
        (11, 12), (12, 13),         # left leg
        (0, 14), (0, 15),           # face
        (14, 16), (15, 17),         # ears
    ]
    
    # Draw connections
    for start_idx, end_idx in connections:
        if start_idx in poses and end_idx in poses:
            draw.line([poses[start_idx], poses[end_idx]], fill='white', width=2)
    
    # Draw keypoints with different colors
    for i, pos in poses.items():
        if i < 5:  # head/torso
            color = 'red'
        elif i < 8:  # arms
            color = 'blue'
        elif i < 14:  # legs
            color = 'green'
        else:  # face
            color = 'yellow'
        draw.ellipse([pos[0]-2, pos[1]-2, pos[0]+2, pos[1]+2], fill=color)
    
    skeleton_tensor = transform(skeleton_img)
    return skeleton_tensor

def create_proper_agnostic_image(person_image, target_size=DEFAULT_IMAGE_SIZE):
    """Create proper person-agnostic image using SCHP human parsing"""
    H, W = target_size
    transform, _, _ = get_transforms()
    
    try:
        # Import the integrated preprocessing module
        sys.path.append('/home/ubuntu/MV-VTON')
        from integrated_preprocessing import IntegratedMVVTONPreprocessor
        
        print("👤 Using SCHP human parsing for agnostic image generation...")
        
        # Create preprocessor and generate agnostic image
        preprocessor = IntegratedMVVTONPreprocessor(target_size=target_size, device=device)
        person_data = preprocessor.process_person_image(person_image)
        
        # Return the agnostic image and mask tensors
        return person_data['agnostic'], person_data['parsing_mask']
        
    except Exception as e:
        print(f"⚠️ SCHP agnostic generation failed ({e}), using simple fallback mask")
        print(f"   Error details: {traceback.format_exc()}")
        
        # Fallback to simple approach
        person_tensor = preprocess_person_image(person_image, target_size)
        inpaint_mask = create_simple_inpaint_mask(target_size)
        agnostic_image = person_tensor * (1 - inpaint_mask) + inpaint_mask * 0.0
        
        return agnostic_image, inpaint_mask

def create_simple_inpaint_mask(target_size=DEFAULT_IMAGE_SIZE):
    """Create a simple inpaint mask for the torso area"""
    H, W = target_size
    _, _, transform_mask = get_transforms()
    
    # Create mask for torso area
    mask_img = Image.new('L', (W, H), color=0)
    draw = ImageDraw.Draw(mask_img)
    
    # Draw torso mask (rectangle covering the torso area)
    torso_top = H // 4
    torso_bottom = 3 * H // 4
    torso_left = W // 6
    torso_right = 5 * W // 6
    
    draw.rectangle([torso_left, torso_top, torso_right, torso_bottom], fill=255)
    
    mask_tensor = transform_mask(mask_img)
    return mask_tensor

def mvvton_inference(person_img, cloth_img, cloth_back_img=None, ddim_steps=DEFAULT_DDIM_STEPS, scale=DEFAULT_SCALE, H=512, W=384):
    """Complete MV-VTON inference pipeline"""
    try:
        if model is None or sampler is None:
            raise ValueError("Model not loaded")
            
        print(f"🚀 Starting MV-VTON inference with steps={ddim_steps}, scale={scale}, size={H}x{W}")
        
        # Preprocess images
        person_tensor = preprocess_person_image(person_img, (H, W))
        cloth_tensor, ref_image_f, cloth_mask = preprocess_cloth_image(cloth_img, (H, W))
        
        # Handle back cloth (use front cloth if back not provided)
        if cloth_back_img is not None:
            cloth_back_tensor, ref_image_b, _ = preprocess_cloth_image(cloth_back_img, (H, W))
        else:
            cloth_back_tensor = cloth_tensor.clone()
            ref_image_b = ref_image_f.clone()
        
        # Create skeleton poses using proper preprocessing
        try:
            skeleton_p = create_proper_skeleton_pose(person_img, (H, W))   # person skeleton
            print("✅ Using proper OpenPose-style skeleton")
        except:
            skeleton_p = create_improved_fallback_skeleton_pose((H, W))   # person skeleton
            print("⚠️ Using improved fallback skeleton")
            
        skeleton_cf = skeleton_p.clone()  # cloth front skeleton (same as person)
        skeleton_cb = skeleton_p.clone()  # cloth back skeleton (same as person)
        
        # Create person-agnostic image and inpaint mask using proper preprocessing
        try:
            inpaint_image, inpaint_mask = create_proper_agnostic_image(person_img, (H, W))
            print("✅ Using SCHP-based agnostic image")
        except:
            # Fallback to simple approach
            inpaint_mask = create_simple_inpaint_mask((H, W))
            inpaint_image = person_tensor * (1 - inpaint_mask) + inpaint_mask * 0.0
            print("⚠️ Using simple fallback agnostic image")
        
        # Create warp features - use cloth tensor as starting point
        # Note: In production, this should be replaced with proper cloth warping
        warp_feat = cloth_tensor.clone()
        
        # Move tensors to device
        device_tensors = {}
        device_tensors['person'] = person_tensor.unsqueeze(0).to(device)
        device_tensors['inpaint_image'] = inpaint_image.unsqueeze(0).to(device)
        device_tensors['inpaint_mask'] = inpaint_mask.unsqueeze(0).to(device)
        device_tensors['ref_f'] = ref_image_f.unsqueeze(0).to(device)
        device_tensors['ref_b'] = ref_image_b.unsqueeze(0).to(device)
        device_tensors['skeleton_cf'] = skeleton_cf.unsqueeze(0).to(device)
        device_tensors['skeleton_cb'] = skeleton_cb.unsqueeze(0).to(device)
        device_tensors['skeleton_p'] = skeleton_p.unsqueeze(0).to(device)
        device_tensors['controlnet_cond_f'] = cloth_tensor.unsqueeze(0).to(device)
        device_tensors['controlnet_cond_b'] = cloth_back_tensor.unsqueeze(0).to(device)
        device_tensors['warp_feat'] = warp_feat.unsqueeze(0).to(device)
        
        with torch.no_grad():
            with autocast("cuda"):
                with model.ema_scope():
                    # Prepare conditioning
                    ref_tensor = device_tensors['ref_f']  # Use front view for now
                    
                    # Get learned conditioning
                    uc = None
                    if scale != 1.0:
                        uc = model.learnable_vector
                        uc = uc.repeat(ref_tensor.size(0), 1, 1)
                    
                    c = model.get_learned_conditioning(ref_tensor.to(torch.float16))
                    c = model.proj_out(c)
                    
                    # Prepare model kwargs
                    test_model_kwargs = {}
                    test_model_kwargs['inpaint_mask'] = device_tensors['inpaint_mask']
                    test_model_kwargs['inpaint_image'] = device_tensors['inpaint_image']
                    
                    # Encode to latent space
                    z_inpaint = model.encode_first_stage(test_model_kwargs['inpaint_image'])
                    z_inpaint = model.get_first_stage_encoding(z_inpaint).detach()
                    test_model_kwargs['inpaint_image'] = z_inpaint
                    test_model_kwargs['inpaint_mask'] = Resize([z_inpaint.shape[-2], z_inpaint.shape[-1]])(
                        test_model_kwargs['inpaint_mask'])
                    
                    # Encode warp features
                    warp_feat_encoded = model.encode_first_stage(device_tensors['warp_feat'])
                    warp_feat_encoded = model.get_first_stage_encoding(warp_feat_encoded).detach()
                    
                    # Add noise for starting point
                    ts = torch.full((1,), 999, device=device, dtype=torch.long)
                    start_code = model.q_sample(warp_feat_encoded, ts)
                    
                    # ControlNet processing
                    ehs_cf = model.pose_model(device_tensors['skeleton_cf'])
                    ehs_cb = model.pose_model(device_tensors['skeleton_cb'])
                    ehs_p = model.pose_model(device_tensors['skeleton_p'])
                    ehs_text = torch.zeros((c.shape[0], 1, 768)).to(device)
                    
                    # Prepare input for ControlNet
                    x_noisy = torch.cat((start_code, test_model_kwargs['inpaint_image'], test_model_kwargs['inpaint_mask']), dim=1)
                    
                    # ControlNet forward pass
                    down_samples_f, mid_samples_f = model.local_controlnet(
                        x_noisy, ts,
                        encoder_hidden_states=ehs_text,
                        controlnet_cond=device_tensors['controlnet_cond_f'],
                        ehs_c=ehs_cf,
                        ehs_p=ehs_p
                    )
                    
                    down_samples_b, mid_samples_b = model.local_controlnet(
                        x_noisy, ts,
                        encoder_hidden_states=ehs_text,
                        controlnet_cond=device_tensors['controlnet_cond_b'],
                        ehs_c=ehs_cb,
                        ehs_p=ehs_p
                    )
                    
                    # Combine front and back ControlNet features
                    mid_samples = mid_samples_f + mid_samples_b
                    down_samples = ()
                    for ds in range(len(down_samples_f)):
                        tmp = torch.cat((down_samples_f[ds], down_samples_b[ds]), dim=1)
                        down_samples = down_samples + (tmp,)
                    
                    # DDIM sampling
                    shape = [4, H // 8, W // 8]  # Latent shape
                    samples_ddim, _ = sampler.sample(
                        S=ddim_steps,
                        conditioning=c,
                        batch_size=1,
                        shape=shape,
                        verbose=False,
                        unconditional_guidance_scale=scale,
                        unconditional_conditioning=uc,
                        eta=0.0,
                        x_T=start_code,
                        down_samples=down_samples,
                        test_model_kwargs=test_model_kwargs
                    )
                    
                    # Decode to image
                    x_samples_ddim = model.decode_first_stage(samples_ddim)
                    x_samples_ddim = torch.clamp((x_samples_ddim + 1.0) / 2.0, min=0.0, max=1.0)
                    
                    # Apply mask blending - preserve generated content in masked areas
                    x_source = torch.clamp((device_tensors['person'] + 1.0) / 2.0, min=0.0, max=1.0)
                    mask_for_blend = device_tensors['inpaint_mask']
                    # Fix: Use generated content in masked areas, keep original in non-masked areas
                    x_result = x_source * (1 - mask_for_blend) + x_samples_ddim * mask_for_blend
                    
                    # Convert to PIL Image
                    result_np = x_result.squeeze(0).permute(1, 2, 0).cpu().numpy()
                    result_np = (result_np * 255).astype(np.uint8)
                    result_img = Image.fromarray(result_np)
                    
                    print("✅ MV-VTON inference completed successfully!")
                    return result_img
                    
    except Exception as e:
        print(f"❌ Error in MV-VTON inference: {e}")
        traceback.print_exc()
        return None

# API Endpoints

@app.route('/health', methods=['GET'])
def health_check():
    """Comprehensive health check endpoint"""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "model_loaded": model is not None,
        "sampler_ready": sampler is not None,
        "config_loaded": config is not None,
        "device": str(device) if device else "None",
        "cuda_available": torch.cuda.is_available(),
        "gpu_count": torch.cuda.device_count(),
        "pytorch_version": torch.__version__,
        "default_image_size": DEFAULT_IMAGE_SIZE,
        "supported_formats": ["JPEG", "PNG", "RGB"],
        "api_version": "1.0.0"
    })

@app.route('/model/info', methods=['GET'])
def model_info():
    """Get detailed model information"""
    if model is None:
        return jsonify({"error": "Model not loaded"}), 500
        
    return jsonify({
        "model_type": "LatentTryOnDiffusion",
        "config_path": DEFAULT_CONFIG_PATH,
        "checkpoint_path": DEFAULT_CHECKPOINT_PATH,
        "image_size": DEFAULT_IMAGE_SIZE,
        "default_ddim_steps": DEFAULT_DDIM_STEPS,
        "default_scale": DEFAULT_SCALE,
        "conditioning_type": "crossattn",
        "channels": 4,
        "scale_factor": 0.18215,
        "model_parameters": sum(p.numel() for p in model.parameters()) if model else 0
    })

@app.route('/try-on', methods=['POST'])
def virtual_try_on():
    """Main virtual try-on endpoint returning base64 image"""
    try:
        start_time = datetime.now()
        
        if model is None or sampler is None:
            return jsonify({"error": "MV-VTON model not loaded"}), 500
        
        # Validate required files
        if 'person_image' not in request.files:
            return jsonify({"error": "Person image not provided"}), 400
        if 'cloth_image' not in request.files:
            return jsonify({"error": "Cloth image not provided"}), 400
        
        # Get uploaded files
        person_file = request.files['person_image']
        cloth_file = request.files['cloth_image']
        cloth_back_file = request.files.get('cloth_back_image')  # Optional
        
        # Validate filenames
        if not person_file.filename or not cloth_file.filename:
            return jsonify({"error": "Invalid file names"}), 400
        
        # Get parameters
        ddim_steps = int(request.form.get('ddim_steps', DEFAULT_DDIM_STEPS))
        scale = float(request.form.get('scale', DEFAULT_SCALE))
        height = int(request.form.get('height', DEFAULT_IMAGE_SIZE[0]))
        width = int(request.form.get('width', DEFAULT_IMAGE_SIZE[1]))
        
        # Validate parameters
        if ddim_steps < 1 or ddim_steps > 200:
            return jsonify({"error": "ddim_steps must be between 1 and 200"}), 400
        if scale < 0.0 or scale > 10.0:
            return jsonify({"error": "scale must be between 0.0 and 10.0"}), 400
        if height < 256 or height > 1024 or width < 256 or width > 1024:
            return jsonify({"error": "Image size must be between 256 and 1024 pixels"}), 400
        
        # Load and validate images
        try:
            person_img = Image.open(person_file.stream).convert('RGB')
            cloth_img = Image.open(cloth_file.stream).convert('RGB')
            cloth_back_img = None
            
            if cloth_back_file and cloth_back_file.filename:
                cloth_back_img = Image.open(cloth_back_file.stream).convert('RGB')
                
        except Exception as e:
            return jsonify({"error": f"Failed to load images: {str(e)}"}), 400
        
        print(f"📸 Processing images: person={person_img.size}, cloth={cloth_img.size}")
        
        # Run MV-VTON inference
        result_img = mvvton_inference(
            person_img, cloth_img, cloth_back_img,
            ddim_steps=ddim_steps,
            scale=scale,
            H=height,
            W=width
        )
        
        if result_img is None:
            return jsonify({"error": "MV-VTON inference failed"}), 500
        
        # Convert result to base64
        buffer = io.BytesIO()
        result_img.save(buffer, format='PNG')
        buffer.seek(0)
        result_base64 = base64.b64encode(buffer.getvalue()).decode()
        
        processing_time = (datetime.now() - start_time).total_seconds()
        
        return jsonify({
            "success": True,
            "result_image": result_base64,
            "message": "MV-VTON virtual try-on completed successfully",
            "processing_time": f"{processing_time:.2f}s",
            "parameters": {
                "ddim_steps": ddim_steps,
                "scale": scale,
                "output_size": [height, width],
                "person_input_size": list(person_img.size),
                "cloth_input_size": list(cloth_img.size),
                "has_back_cloth": cloth_back_img is not None
            },
            "timestamp": datetime.now().isoformat(),
            "note": "This implementation includes simplified preprocessing. For production use, integrate human parsing, pose detection, and cloth warping components."
        })
        
    except Exception as e:
        error_msg = f"MV-VTON API error: {str(e)}"
        print(f"❌ {error_msg}")
        traceback.print_exc()
        return jsonify({
            "error": error_msg,
            "timestamp": datetime.now().isoformat()
        }), 500

@app.route('/try-on-file', methods=['POST'])
def virtual_try_on_file():
    """Virtual try-on endpoint returning image file"""
    try:
        # Similar validation as main endpoint
        if model is None or sampler is None:
            return jsonify({"error": "MV-VTON model not loaded"}), 500
            
        if 'person_image' not in request.files or 'cloth_image' not in request.files:
            return jsonify({"error": "Missing required images"}), 400
        
        person_file = request.files['person_image']
        cloth_file = request.files['cloth_image']
        cloth_back_file = request.files.get('cloth_back_image')
        
        # Get parameters
        ddim_steps = int(request.form.get('ddim_steps', DEFAULT_DDIM_STEPS))
        scale = float(request.form.get('scale', DEFAULT_SCALE))
        height = int(request.form.get('height', DEFAULT_IMAGE_SIZE[0]))
        width = int(request.form.get('width', DEFAULT_IMAGE_SIZE[1]))
        
        # Load images
        person_img = Image.open(person_file.stream).convert('RGB')
        cloth_img = Image.open(cloth_file.stream).convert('RGB')
        cloth_back_img = None
        
        if cloth_back_file and cloth_back_file.filename:
            cloth_back_img = Image.open(cloth_back_file.stream).convert('RGB')
        
        # Run inference
        result_img = mvvton_inference(
            person_img, cloth_img, cloth_back_img,
            ddim_steps=ddim_steps,
            scale=scale,
            H=height,
            W=width
        )
        
        if result_img is None:
            return jsonify({"error": "MV-VTON inference failed"}), 500
        
        # Save to temporary file
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.png')
        result_img.save(temp_file.name)
        temp_file.close()
        
        return send_file(
            temp_file.name,
            mimetype='image/png',
            as_attachment=True,
            download_name=f'mvvton_result_{datetime.now().strftime("%Y%m%d_%H%M%S")}.png'
        )
        
    except Exception as e:
        return jsonify({
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }), 500

if __name__ == '__main__':
    print("🚀 Starting MV-VTON Integrated API Server...")
    print(f"📍 Working directory: {os.getcwd()}")
    print(f"🐍 Python version: {sys.version}")
    print(f"🔥 PyTorch version: {torch.__version__}")
    print(f"🎯 CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"💾 GPU count: {torch.cuda.device_count()}")
        print(f"🔧 GPU name: {torch.cuda.get_device_name()}")
    
    print("\n" + "="*60)
    print("🤖 INITIALIZING MV-VTON MODEL...")
    print("="*60)
    
    # Initialize the model
    if not initialize_mvvton_model():
        print("❌ Failed to initialize MV-VTON model. Exiting.")
        sys.exit(1)
    
    print("\n" + "="*60)
    print("✅ MV-VTON MODEL READY!")
    print("🌐 Starting Flask server on 0.0.0.0:5000")
    print("📖 Available endpoints:")
    print("   GET  /health - Health check and system status")
    print("   GET  /model/info - Model configuration details")
    print("   POST /try-on - Virtual try-on (returns base64 image)")
    print("   POST /try-on-file - Virtual try-on (returns image file)")
    print("="*60 + "\n")
    
    # Start the Flask server
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)