#!/bin/bash

# MV-VTON Gradio App Startup Script - Environment Isolation Version
# This script runs Gradio in the BASE environment to avoid package conflicts
# while the API server runs in the mv-vton conda environment

set -e

echo "🌐 MV-VTON Gradio Web Interface Startup (Environment Isolation)"
echo "=============================================================="

# Check if conda is available
if ! command -v conda &> /dev/null; then
    echo "❌ Conda not found. Please install conda or miniconda."
    exit 1
fi

# Initialize conda for shell script
eval "$(conda shell.bash hook)"

# IMPORTANT: Deactivate any conda environment to use base environment
echo "🔧 Using base Python environment for Gradio (avoiding package conflicts)..."
conda deactivate 2>/dev/null || true  # Deactivate any active environment

# Check if API server is running
echo "🔍 Checking API server status..."
if curl -s http://localhost:5000/health > /dev/null 2>&1; then
    echo "✅ API server is running on localhost:5000"
else
    echo "⚠️  API server not detected on localhost:5000"
    echo ""
    echo "📝 IMPORTANT: You need to start the API server first!"
    echo "   In another terminal, run: ./start_api_server.sh"
    echo ""
    echo "🤔 Do you want to:"
    echo "   1. Continue starting Gradio (you can start API server later)"
    echo "   2. Exit and start API server first"
    echo ""
    read -p "Enter choice (1 or 2): " choice
    
    case $choice in
        1)
            echo "🚀 Starting Gradio app (remember to start API server)..."
            ;;
        2)
            echo "👋 Please start the API server first: ./start_api_server.sh"
            exit 0
            ;;
        *)
            echo "Invalid choice. Starting Gradio app..."
            ;;
    esac
fi

# Install required packages in base environment (avoiding conda environment conflicts)
echo "📦 Installing/checking packages in base environment..."

# Check Python version
python_version=$(python --version 2>&1 | cut -d' ' -f2)
echo "🐍 Using Python: $python_version (base environment)"

# Install gradio and required packages in base environment
echo "📦 Ensuring required packages are installed..."
pip install --upgrade gradio requests pillow numpy

# Verify installations
echo "🔍 Verifying package installations..."
packages=("gradio" "requests" "PIL" "numpy")
missing_packages=()

for package in "${packages[@]}"; do
    if ! python -c "import $package; print(f'✅ {$package} imported successfully')" 2>/dev/null; then
        missing_packages+=($package)
    fi
done

if [ ${#missing_packages[@]} -ne 0 ]; then
    echo "❌ Missing packages detected: ${missing_packages[*]}"
    echo "🔧 Attempting to install missing packages..."
    
    for pkg in "${missing_packages[@]}"; do
        if [ "$pkg" == "PIL" ]; then
            pip install Pillow
        else
            pip install "$pkg"
        fi
    done
else
    echo "✅ All required packages are available"
fi

echo ""
echo "🌟 Starting Gradio Web Interface in Base Environment..."
echo "🔗 Local access: http://localhost:7860"
echo "🔗 Network access: http://$(hostname -I | awk '{print $1}'):7860"
echo ""
echo "📋 Environment Isolation Setup:"
echo "   ✅ API Server: Running in mv-vton conda environment (localhost:5000)"
echo "   ✅ Gradio UI: Running in base environment (localhost:7860)"
echo "   ✅ Package Conflicts: Resolved via environment separation"
echo ""
echo "📋 Usage Notes:"
echo "   • API server should be running on localhost:5000 (mv-vton environment)"
echo "   • Upload person and clothing images to get started"
echo "   • Use advanced parameters to fine-tune results"
echo ""
echo "Press Ctrl+C to stop the application"
echo "=============================================================="
echo ""

# Start the Gradio app in base environment
echo "🚀 Launching full-featured Gradio application with gradio_app.py..."
python gradio_app.py